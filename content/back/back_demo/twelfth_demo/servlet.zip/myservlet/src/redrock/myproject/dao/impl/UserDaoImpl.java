package redrock.myproject.dao.impl;

import redrock.myproject.dao.IUserDao;
import redrock.myproject.domain.User;
import com.mysql.jdbc.Driver;
import java.sql.*;

public class UserDaoImpl implements IUserDao{
    String url="jdbc:mysql://localhost/"+"test"+"?user="+"root"+"&password="+"root";//连接数据库的url
    private Connection con;
    public UserDaoImpl(){//初始化连接
        try
        {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            con = DriverManager.getConnection(url);//连接数据库
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    @Override
    public User find(String userName, String userPwd) {
        try {
            Statement stmt=con.createStatement();
            String sql="select * from  user where username='"+userName+"';";
            ResultSet rs=stmt.executeQuery(sql);
            if(rs.next())
            {
                String passwordR=new String(rs.getString("userpwd"));
                if(passwordR.equals(userPwd)){
                    User user = new User();
                    user.setId(rs.getString("id"));
                    user.setEmail(rs.getString("email"));
                    user.setUserPwd(rs.getString("userPwd"));
                    user.setUserName(rs.getString("userName"));
                    return user;
                }else{
                    return null;
                }
            }

        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void add(User user) {
        String reg="insert into user(username , userpwd , email)  values(?,?,?)";

        try
        {
            PreparedStatement pstmt=con.prepareStatement(reg);
            pstmt.setString(1,user.getUserName());
            pstmt.setString(2,user.getUserPwd());
            pstmt.setString(3,user.getEmail());
            pstmt.executeUpdate();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean find(String userName) {
        try {
            Statement stmt=con.createStatement();
            String sql="select * from  user where username='"+userName+"';";
            ResultSet rs=stmt.executeQuery(sql);
            if(rs.next())
            {
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}

