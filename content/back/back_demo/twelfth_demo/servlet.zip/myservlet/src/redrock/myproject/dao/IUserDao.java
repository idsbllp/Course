package redrock.myproject.dao;
import redrock.myproject.domain.User;
public interface IUserDao {
    /**
     * 根据用户名密码查找用户
     * @param userName
     * @param userPwd
     * @return 查找到的用户
     */
    User find(String userName , String userPwd);

    /**
     * 添加用户
     * @param user
     */
    void add(User user);

    /**
     * 根据用户名查找用户
     * @param userName
     */
    boolean find(String userName);
}
