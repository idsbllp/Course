package redrock.myproject.serlet.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import redrock.myproject.domain.User;
import redrock.myproject.exception.UserExistException;
import redrock.myproject.serlet.formbean.RegisterFormBean;
import redrock.myproject.service.IUserService;
import redrock.myproject.service.impl.UserServiceImpl;
import redrock.myproject.util.WebUtils;


/**
 * 处理用户注册的Servlet
 */
@WebServlet(name = "Register" , value = "/servlet/RegisterServlet")
public class RegisterServlet extends HttpServlet {

	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		//将客户端提交的表单数据封装到RegisterFormBean对象中
		RegisterFormBean formbean = WebUtils.request2Bean(req,RegisterFormBean.class);
		//校验用户注册填写的表单数据
		if (formbean.validate() == false) {//如果校验失败
			//将封装了用户填写的表单数据的formbean对象发送回register.jsp页面的form表单中进行显示
			req.setAttribute("formbean", formbean);
			//校验失败就说明是用户填写的表单数据有问题，那么就跳转回register.jsp
			req.getRequestDispatcher("/WEB-INF/register.jsp").forward(req, resp);
			return;
		}

		User user = new User();
		try {
			BeanUtils.copyProperties(user, formbean);//把表单的数据填充到javabean中
			IUserService service = new UserServiceImpl();
			//调用service层提供的注册用户服务实现用户注册
			service.registerUser(user);
			String message = String.format(
					"注册成功！！3秒后为您自动跳到登录页面！！<meta http-equiv='refresh' content='3;url=%s'/>",
					req.getContextPath()+"/servlet/LoginUIServlet");
			req.setAttribute("message",message);
			req.getRequestDispatcher("/message.jsp").forward(req,resp);

		} catch (UserExistException e) {
			formbean.getErrors().put("userName", "注册用户已存在！！");
			req.setAttribute("formbean", formbean);
			req.getRequestDispatcher("/WEB-INF/register.jsp").forward(req, resp);
		} catch (Exception e) {
			e.printStackTrace(); // 在后台记录异常
			req.setAttribute("message", "对不起，注册失败！！");
			req.getRequestDispatcher("/message.jsp").forward(req,resp);
		}
	}

}
