package redrock.myproject.util;

import org.apache.commons.beanutils.BeanUtils;

import javax.servlet.http.HttpServletRequest;
import java.util.Enumeration;

/**
 * 把request对象中的请求参数封装到bean中
 */

public class WebUtils {
    /**
     * 将request对象转换成T对象
     * @param request
     * @param clazz
     * @param <T>
     * @return
     */
    public static <T> T request2Bean(HttpServletRequest request, Class<T> clazz){
        try{
            T bean = clazz.newInstance();//创建bean
            Enumeration<String> e = request.getParameterNames(); //用枚举接口获取request中key-value
            while(e.hasMoreElements()){//是否还有元素，如果有返回true，否则表示至少含有一个元素
                String name = (String) e.nextElement();//如果Enumeration枚举对象还有元素，返回对象只能的下一个元素，否则抛出NoSuchElementException异常。
                String value = request.getParameter(name);
                BeanUtils.setProperty(bean, name, value);//其中bean是指你将要设置的对象，name指的是将要设置的属性（属性名）,value（字符串值）
            }
            return bean;
        }catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
