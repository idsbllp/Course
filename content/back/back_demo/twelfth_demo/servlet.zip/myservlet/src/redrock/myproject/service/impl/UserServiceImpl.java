package redrock.myproject.service.impl;

import redrock.myproject.dao.IUserDao;
import redrock.myproject.dao.impl.UserDaoImpl;
import redrock.myproject.domain.User;
import redrock.myproject.exception.UserExistException;
import redrock.myproject.service.IUserService;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UserServiceImpl implements IUserService{

    private IUserDao userDao = new UserDaoImpl();

    @Override
    public void registerUser(User user) throws UserExistException{
        if (userDao.find(user.getUserName())) {
            UserExistException a = new UserExistException("注册的用户名已存在！！！");
            throw a;
        }else {
            userDao.add(user);
        }
    }

    @Override
    public User loginUser(String userName, String userPwd) {
        return userDao.find(userName, userPwd);
    }
}
