package redrock.myproject.domain;
import java.io.Serializable;
import java.util.Date;

/**
 * @author momo
 * 用户实体类
 */

public class User {

    public String getId() {
        return id;
    }

    private String id;
    private String userName;
    private String userPwd;
    private String email;

    public void setId(String id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public String getUserPwd() {
        return userPwd;
    }
    public void setUserPwd(String userPwd) {
        this.userPwd = userPwd;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
}
